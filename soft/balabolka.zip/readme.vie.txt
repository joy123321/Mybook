﻿Balabolka, phiên bản 2.15.0.885
Bản quyền (c) 2006-2024 Ilya Morozov
Đã đăng ký Bản quyền

WWW: https://www.cross-plus-a.com/balabolka.htm
Email: crossa@list.ru

Giấy phép: Phần mềm miễn phí (Freeware)
Hệ điều hành: Microsoft Windows XP/Vista/7/8/10/11
API Microsoft Speech: v4.0/5.0 trở lên
Nền tảng giọng nói của Microsoft: v11.0



*** Cài đặt ***

    Nếu bạn nhận được phiên bản Balabolka này ở dạng tệp ZIP (ví dụ: BALABOLKA.ZIP), bạn có thể cài đặt nó như sau:

    1 Giải nén file vào thư mục TEMP
    2 Chọn Chạy từ menu Bắt đầu trên Thanh tác vụ
    3 Nhập tên đầy đủ của tệp (ví dụ: C:\TEMP\SETUP.EXE)
    4 Bấm phím Enter và làm theo lời nhắc

    Để cài đặt Balabolka ở chế độ im lặng không có hộp thoại, bạn có thể sử dụng cài đặt im lặng.
    Cài đặt và gỡ cài đặt im lặng có sẵn bằng cách sử dụng chuyển đổi dòng lệnh "-silent".



*** Công cụ chuyển văn bản thành giọng nói ***

    Balabolka sử dụng công cụ Chuyển văn bản thành giọng nói (Text-To-Speech, TTS) để đọc các tệp văn bản.
    Nếu bạn đã cài đặt công cụ giọng nói, bạn sẽ thấy danh sách các giọng nói có sẵn trong cửa sổ chính của Balabolka.

    Chương trình hỗ trợ cả công cụ chuyển văn bản thành giọng nói SAPI 4 và SAPI 5.
    SAPI 4 là công nghệ lỗi thời nên tôi khuyên bạn nên sử dụng SAPI 5.

    Nếu bạn quan tâm đến một số giọng nói chất lượng cao hơn, vui lòng tìm thêm thông tin trong tệp trợ giúp của Balabolka.



*** Nền tảng giọng nói của Microsoft ***

    Nền tảng giọng nói của Microsoft bao gồm Ngôn ngữ thời gian chạy và Ngôn ngữ thời gian chạy (công cụ nhận dạng giọng nói và chuyển văn bản thành giọng nói).
    Có các Ngôn ngữ thời gian chạy riêng biệt để nhận dạng giọng nói và tổng hợp giọng nói.

    https://msdn.microsoft.com/en-us/library/hh361572.aspx

    Hãy làm theo các bước sau để cài đặt Microsoft Speech Platform:

    1 Gỡ cài đặt mọi phiên bản trước đó của Speech Platform Runtime khỏi máy tính của bạn.
    2 Xác định xem bạn đang sử dụng hệ điều hành 32 bit hay 64 bit.
    3 Tải xuống và cài đặt Speech Platform Runtime phù hợp với hệ điều hành của bạn.
    4 Tải xuống và cài đặt Ngôn ngữ thời gian chạy để sử dụng với Nền tảng giọng nói.

    Balabolka là ứng dụng 32-bit. Bạn cần cài đặt gói Runtime 32-bit cho Microsoft Speech Platform để sử dụng gói này trong Balabolka.



*** Quyên góp ***

    Nếu bạn muốn giúp Balabolka, hãy mua phần mềm Cross+A của tôi:

    https://www.cross-plus-a.com

    Miễn là mọi người trả tiền cho Cross+A, Balabolka sẽ vẫn là phần mềm miễn phí.

    Cảm ơn!

###